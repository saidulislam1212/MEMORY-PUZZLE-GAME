const board = document.getElementById('game-board');
const timerEl = document.getElementById('timer');
const scoreEl = document.getElementById('score');
const restartBtn = document.getElementById('restart');

let cards = [];
let flippedCards = [];
let matchedPairs = 0;
let timeLeft = 60;
let timer;

const symbols = ['🍎', '🍌', '🍇', '🍓', '🍉', '🍒', '🥝', '🍍'];

function shuffle(array) {
  return array.sort(() => 0.5 - Math.random());
}

function createBoard() {
  const doubledSymbols = [...symbols, ...symbols];
  const shuffled = shuffle(doubledSymbols);

  board.innerHTML = '';
  shuffled.forEach((symbol, index) => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.dataset.symbol = symbol;
    card.dataset.index = index;
    card.innerText = '';
    card.addEventListener('click', handleCardClick);
    board.appendChild(card);
    cards.push(card);
  });
}

function handleCardClick(e) {
  const card = e.currentTarget;

  if (card.classList.contains('flipped') || card.classList.contains('matched') || flippedCards.length === 2) {
    return;
  }

  card.classList.add('flipped');
  card.innerText = card.dataset.symbol;
  flippedCards.push(card);

  if (flippedCards.length === 2) {
    setTimeout(checkMatch, 800);
  }
}

function checkMatch() {
  const [card1, card2] = flippedCards;

  if (card1.dataset.symbol === card2.dataset.symbol) {
    card1.classList.add('matched');
    card2.classList.add('matched');
    matchedPairs++;
    scoreEl.innerText = Matches: ${matchedPairs};
    if (matchedPairs === symbols.length) {
      clearInterval(timer);
      alert('🎉 You matched all pairs!');
    }
  } else {
    card1.classList.remove('flipped');
    card2.classList.remove('flipped');
    card1.innerText = '';
    card2.innerText = '';
  }

  flippedCards = [];
}

function startTimer() {
  timeLeft = 60;
  timerEl.innerText = Time: ${timeLeft}s;
  timer = setInterval(() => {
    timeLeft--;
    timerEl.innerText = Time: ${timeLeft}s;
    if (timeLeft <= 0) {
      clearInterval(timer);
      alert('⏰ Time is up!');
      disableBoard();
    }
  }, 1000);
}

function disableBoard() {
  cards.forEach(card => card.removeEventListener('click', handleCardClick));
}

function resetGame() {
  clearInterval(timer);
  cards = [];
  flippedCards = [];
  matchedPairs = 0;
  scoreEl.innerText = 'Matches: 0';
  createBoard();
  startTimer();
}

restartBtn.addEventListener('click', resetGame);

window.onload = resetGame;